# talstack-todo-test

Run `docker-compose up` to boot up postgres and run `stack build` followed by `stack exec` to run the server.

Head over to `http://localhost:3000` to interact with the UI.

Run the tests with `stack test`