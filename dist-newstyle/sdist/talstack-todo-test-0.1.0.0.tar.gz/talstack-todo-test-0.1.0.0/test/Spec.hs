{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE DeriveGeneric #-}

import Test.Hspec
import Test.Hspec.Wai
import Test.Hspec.Wai.JSON
import Network.Wai.Test (SResponse, runSession, defaultRequest)
import Network.HTTP.Types (status200, status201, status204)
import Control.Monad.IO.Class (liftIO)
import Web.Scotty
import Data.Aeson (ToJSON, encode, object, (.=))
import GHC.Generics (Generic)

data Todo = Todo
  { todoId    :: Int
  , title     :: String
  , completed :: Bool
  } deriving (Show, Generic)

instance ToJSON Todo

-- Mock database operations
mockGetTodos :: Connection -> IO [Todo]
mockGetTodos _ = return [Todo 1 "Mock Todo 1" False, Todo 2 "Mock Todo 2" True]

mockAddTodo :: Connection -> String -> IO ()
mockAddTodo _ _ = return ()

mockUpdateTodo :: Connection -> Int -> IO ()
mockUpdateTodo _ _ = return ()

mockDeleteTodo :: Connection -> Int -> IO ()
mockDeleteTodo _ _ = return ()

main :: IO ()
main = hspec $ do
  describe "Todo API" $ do
    it "returns todos" $ do
      let app' = scottyApp $ app mockGetTodos
      response <- request methodGet "/todos" defaultRequest
      response `shouldRespondWith` 200
      response `shouldRespondWith` (encode [Todo 1 "Mock Todo 1" False, Todo 2 "Mock Todo 2" True])

    it "adds a todo" $ do
      let app' = scottyApp $ app mockGetTodos
      response <- request methodPost "/todos" (encode $ object ["title" .= ("New Todo" :: String)])
      response `shouldRespondWith` 201

    it "updates a todo" $ do
      let app' = scottyApp $ app mockGetTodos
      response <- request methodPatch "/todos/1" (encode $ object [])
      response `shouldRespondWith` 204

    it "deletes a todo" $ do
      let app' = scottyApp $ app mockGetTodos
      response <- request methodDelete "/todos/1" defaultRequest
      response `shouldRespondWith` 204